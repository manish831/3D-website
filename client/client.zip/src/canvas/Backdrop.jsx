import React from 'react'

const Backdrop = () => {
  return (
    <div>Backdrop</div>
  )
}

export default Backdrop