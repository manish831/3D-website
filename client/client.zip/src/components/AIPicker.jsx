import React from 'react'

const AIPicker = () => {
  return (
    <div>AIPicker</div>
  )
}

export default AIPicker