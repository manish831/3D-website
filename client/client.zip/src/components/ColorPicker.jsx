import React from 'react'

const ColorPicker = () => {
  return (
    <div>ColorPicker</div>
  )
}

export default ColorPicker