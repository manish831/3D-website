import React from 'react'

const FilePicker = () => {
  return (
    <div>FilePicker</div>
  )
}

export default FilePicker