import React from 'react'

const Tab = () => {
  return (
    <div>Tab</div>
  )
}

export default Tab